avrdude - AVR Downloader/UploaDEr

Source: http://www.nongnu.org/avrdude/